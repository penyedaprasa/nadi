<?php

namespace App\Http\Controllers;

use Validator;
use Carbon\Carbon;
use DB;
use GuzzleHttp\Exception\GuzzleException;
use GuzzleHttp\Client;
use Illuminate\Http\Request;
use App\Petani;
use App\Device;
use App\User;
use App\Administratior;
use App\Tanaman;
use App\JenisTanaman;
use App\PerawatanTanaman;
use App\Notification;
use App\StatusNotif;
use App\StatusTanaman;
use App\Test;

class ApiController extends Controller
{
    //get tanaman
    public function getTanaman()
    {
    	$data = Tanaman::all();
    	return response()->json([
			'msg'  	  => 'success',
			'data' 	  => $data,
			'status'  => 200
		]); 
    }


    // get master tanaman
    public function getTentangTanaman()
    {
    	$data = JenisTanaman::all();
    	return response()->json([
			'msg'  	  => 'success',
			'data' 	  => $data,
			'status'  => 200
		]); 
    }


    // get master notifikasi
    public function getNotif()
    {
    	$data = Notification::all();

    	// $data =Tanaman::where('id_petani', '=', $id)->with('statusNotif.notification')->get();

    	return response()->json([
			'msg'  	  => 'success',
			'data' 	  => $data,
			'status'  => 200
		]); 
    }


	public function getNotifWithId($id)
    {
    	$data = StatusNotif::where('id_petani', '=', $id)->with('notification', 'petani.tanaman')->get();

    	return response()->json([
			'msg'  	  => 'success',
			'data' 	  => $data,
			'status'  => 200
		]); 
    }


   // perawatan atau penjadwalan
    public function getPerawatan($id)
    {
    	// $data =Tanaman::where('id_petani', '=', $id)->with('JenisTanaman.perawatanTanaman')->get();
    	// $data = PerawatanTanaman::with('JenisTanaman.Tanaman')->get();
    	// $data2 = [];
    	// $data = json_decode($data, true);
    	// foreach ($data as $key => $value) {
	    // 	$tanam = date("Y-m-d", strtotime($value['tgl_tanam']));
	    //     $datetime1 = new Carbon($tanam);
	    //     $datetime2 = now();
	    //     $interval = date_diff($datetime1, $datetime2);
	    //     $interval = $datetime1->diff($datetime2);
	    //     $now_usia = $interval->format('%a');
    	// 	$data[$key]['usia'] = $now_usia;
    		
    	// }
    	$data = DB::select("SELECT * FROM tb_perawatan_tanaman p INNER JOIN tb_jenis_tanaman j ON p.id_jenis_tanaman = j.id_jenis_tanaman INNER JOIN tb_tanaman t ON j.id_jenis_tanaman = t.id_jenis_tanaman WHERE t.id_petani='$id'");

    	return response()->json([
			'msg'  	  => 'success',
			'data' 	  => $data,
			'status'  => 200
		]);
    }


    // get semua tanaman dengan id petani
    public function getKebunkuWithId($id)
    {
    	$qry =Tanaman::where('id_petani', '=', $id)->with('device', 'jenisTanaman', 'statusTanamanOne')->get();
    	$data2 = [];
    	$data = json_decode($qry, true);
    	foreach ($data as $key => $value) {
	    	$tanam = date("Y-m-d", strtotime($value['tgl_tanam']));
	        $datetime1 = new Carbon($tanam);
	        $datetime2 = now();
	        $interval = date_diff($datetime1, $datetime2);
	        $interval = $datetime1->diff($datetime2);
	        $now_usia = $interval->format('%a');
    		$data[$key]['usia'] = $now_usia;
    		
    	}

        // dd($data);


    	return response()->json([
			'msg'  	  => 'success',
			'data' 	  => $data,
			'status'  => 200
		]);
    }

    public function getChart($id)
    {
    	$qry =Tanaman::where('id_tanaman', '=', $id)->with('statusTanaman')->limit(21)->get();
    	$data2 = [];
    	$data = json_decode($qry, true);
    	foreach ($data as $key => $value) {
	    	$tanam = date("Y-m-d", strtotime($value['tgl_tanam']));
	        $datetime1 = new Carbon($tanam);
	        $datetime2 = now();
	        $interval = date_diff($datetime1, $datetime2);
	        $interval = $datetime1->diff($datetime2);
	        $now_usia = $interval->format('%a');
    		$data[$key]['usia'] = $now_usia;
    		
    	}
        // dd($data);
    	return response()->json([
			'msg'  	  => 'success',
			'data' 	  => $data,
			'status'  => 200
		]);
    }

   
    // get kebunku
    public function getKebunku($id)
    {
    	$data = Tanaman::all();
    	// $data = Lahan::where('id_petani', '=', $id)->with('device', 'tanaman.jenisTanaman', 'statusLahan')->get();
    	return response()->json([
			'msg'  	  => 'success',
			'data' 	  => $data,
			'status'  => 200
		]); 
    }

    // get profile
    public function getProfile($id)
    {
    	// $data = Lahan::all();
    	$data = User::where('id_user', '=', $id)->with('petani')->get();
    	return response()->json([
			'msg'  	  => 'success',
			'data' 	  => $data,
			'status'  => 200
		]); 
    }
	
    // ini proses tambah tanaman

    // get data device
    public function getDevice($id)
    {
    	$data = Device::where('status', '=', 0)->where('id_petani', '=', $id)->get();
    	return response()->json([
			'msg'  	  => 'success',
			'data' 	  => $data,
			'status'  => 200
		]); 
    }

    // get master tanaman
    public function getJenisTanaman()
    {
    	$data = jenisTanaman::all();
    	return response()->json([
			'msg'  	  => 'success',
			'data' 	  => $data,
			'status'  => 200
		]); 
    }

	// post tanaman
	public function postTanaman(Request $request)
	{

		$validator = Validator::make($request->all(), [
            'tgl_tanam'  => 'required',
            'lokasi'  => 'required',
			
			
		]);


		if($validator->fails()){
			return response()->json([
				'msg'  => 'failed create user',
				'error' => $validator->errors(),
				'status' => 401
			]);
		}

		$photo = $request->foto_tanaman;
		$savename = time().'.jpg';
		file_put_contents("images/".$savename, base64_decode($photo));
		$create = Tanaman::create([
			'tgl_tanam'     => $request->tgl_tanam,
			'lokasi'     => $request->lokasi,
			'id_petani' => $request->id_petani,
			'id_jenis_tanaman' => $request->id_jenis_tanaman,
			'id_device' => $request->id_device,
			'foto_tanaman' => $savename

		]);
		if($create){
			$update = Device::where('id_device', '=', $request->id_device)->update([
					'status'  	=> 1

				]);
		}
		return response()->json([
			'msg'  	  => 'success',
			'data' 	  => $create,
			'status'  => 200
		]); 

	}


    // register
 	public function postRegister(Request $request)
	{

		$validator = Validator::make($request->all(), [
            // 'nama'  => 'required',
			'email'  		=> 'required|string|email|max:255|unique:tb_users',
			'password'  	=> 'required',
            // 'id_user' 		=> 'required',
			'nama_petani' 	=> 'required',
			'alamat' 		=> 'required',
			'no_hp'			=> 'required',
			
		]);


		if($validator->fails()){
			return response()->json([
				'msg'  => 'failed create user',
				'error' => $validator->errors(),
				'status' => 401
			]);
		}

		$create = User::create([
			'email'     => $request->email,
			'password'  => encrypt($request->password),
			'level'  	=> 0

		]);
		if($create){

			$photo = $request->foto_petani;
			$savename = time().'.jpg';
			file_put_contents("images/petani/".$savename, base64_decode($photo));

			$create2 = Petani::create([
				'id_user' 		=> $create->id_user, 
				'nama_petani'	=> $request->nama_petani,
				'alamat'		=> $request->alamat,
				'no_hp'			=> $request->no_hp,
				'foto_petani'   => $savename
			
			]);
			if($create2){
				return response()->json([
					'msg'  	  => 'user created',
					'user' 	  => $create,
					'datauser'=>$create2,
					'status'  => 200
				]);
			}
		}

		return response()->json([
			'msg'  => 'failed',
			'error' => 'something error',
			'status' => 400
		]);

	}


	// edit petani
	public function editAkun(Request $request, $id)
	{

		$validator = Validator::make($request->all(), [
            // 'nama'  => 'required',
			// 'email'  		=> 'required|string|email|max:255|unique:tb_users',
			// 'email'  		=> 'required|string|email|max:255',
			'password'  	=> 'required',
			'new_password'  	=> 'required',
            

			
		]);


		if($validator->fails()){
			return response()->json([
				'msg'  => 'failed create user',
				'error' => $validator->errors(),
				'status' => 401
			]);
		}

		if($data = User::select('password')->where('id_user', '=', $id)->where('level', '=', '0')->first()){
			if(decrypt($data->password)==$request->password){
				$update = User::where('id_user', '=', $id)->update([
					// 'email'     => $request->email,
					'password'  => encrypt($request->new_password),
					'level'  	=> 0

				]);
			}
			else{
				return response()->json([
					'msg'  => 'failed update',
					'error' => 'wrong old password',
					'status' => 401
				]);
			}
		}
		 if($update){
            return response()->json([
                'msg'  => 'data updated',
                'data' => '',
                'status' => 200
            ]);
        }

		return response()->json([
			'msg'  => 'failed',
			'error' => 'something error',
			'status' => 400
		]);
	}

	// login
	public function postLogin(Request $request)
	{

		$validator = Validator::make($request->all(), [
			'email'  => 'required',
			'password'  => 'required',
		]);


		if($validator->fails()){
			return response()->json([
				'msg'  => 'failed login',
				'error' => $validator->errors(),
				'status' => 400,
			]);
		}
        // dd(encrypt($request->password));

		if($data = User::with('petani')->where('email', '=', $request->email)->where('level', '=', '0')->first()){
			if(decrypt($data->password)==$request->password){
				return response()->json([
					'msg'  => 'success login as owner',
					'user' => $data,
					'status' => 200,
				]);
			}
		}
		return response()->json([
			'msg'  => 'failed login',
			'error' => 'email or password invalid',
			'status' => 400,
		]);

	}


    // ajdlkha
    public function postStatusPerahu(Request $request)
	{

		$validator = Validator::make($request->all(), [
			'latitude'  	=> 'required',
			'longitude'  	=> 'required',
			'status'   		=> 'required',
			'id_perahu'  	=> 'required'
		]);


		if($validator->fails()){
			return response()->json([
				'msg'  => 'failed create user',
				'error' => $validator->errors(),
				'status' => 401
			]);
		}

		$create = StatusPerahu::create([
			'latitude'  	=> $request->latitude,
			'longitude'  	=> $request->longitude,
			'status'   		=> $request->status,
			'id_perahu'  	=> $request->id_perahu,

		]);

		if($create){
			return response()->json([
				'msg'  	  => 'success',
				'user' 	  => $create,
				'status'  => 200
			]);
		}

		return response()->json([
			'msg'  => 'failed',
			'error' => 'something error',
			'status' => 400
		]);
	}


    public function getFromStation(){
        $client = new Client(); //GuzzleHttp\Client
        $result = $client->get('https://thingspeak.com/channels/530651/feed.json');

        $json = (string) $result->getBody();

        $p = json_decode($json, true);

        $id_channel= $p['channel']['id'];
        $last_entry= $p['channel']['last_entry_id'];
        foreach ($p['feeds'] as $value) {

                //keterangan
    			//temperature = field1 = suhu 
				//humadity = field2 = kelembaban
				//light = field4 = cahaya
				//level_water = field5 = tangki_air
				//ph = field6 = field6 = air_tanah
				//rssi = field7
				//moisture = field3 = nutrisi

	        StatusTanaman::create([
                'id_device'  => '24',
                'id_channel' => $id_channel,
                'cahaya'     => $value['field4'],
                'kelembaban' => $value['field2'],
                'tangki_air' => $value['field5'],
                'suhu' 		 => $value['field1'],
                'nutrisi'	 => $value['field3'],
                // 'entry_id'	 => $value['entry_id'],

                'air_tanah'	 => $value['field6'],
                'rssi'		 => $value['field7'],
                'entry_id'	 => $last_entry,
			]);
        }

        return response()->json([
			'msg'  	  => 'success',
			'data' 	  => $value,
			'status'  => 200
		]); 
		//dd($temperatur);

        //echo $result->getBody();
    }

    // gak ke pake
    public function aksiStatus(){
    	$client = new Client(); //GuzzleHttp\Client
        $result = $client->get('https://thingspeak.com/channels/530651/feed.json');
        $json = (string) $result->getBody();
        $p = json_decode($json, true);
        
        // $id_channel= $p['channel']['id'];
        $last_entry= $p['channel']['last_entry_id'];
        // $qry = StatusTanaman::whereBetween('entry_id', array('96', $last_entry))->get();
      	
      	//keterangan
		//temperature = field1 = suhu 
		//humadity = field2 = kelembaban
		//light = field4 = cahaya
		//level_water = field5 = tangki_air
		//ph = field6 = field6 = air_tanah
		//rssi = field7
		//moisture = field3 = nutrisi

        //mencari nilai terbesar dari tb_status_tanaman
        // $moisture = DB::table('tb_status_tanaman')->whereBetween('entry_id', array(date('2018-07-23 16:33:37')'', $last_entry))->max('nutrisi'); 
        // $qry =statusTanaman::where('id_petani', '=', $id)->with('device', 'jenisTanaman', 'statusTanamanOne')->get();
        

  //       $coba = DB::table('tb_status_tanaman')->whereBetween('created_at', array(date("2018-07-24"), date("Y-m-d")))->max('nutrisi'); 
  //       $moisture = DB::table('tb_status_tanaman')->whereBetween('entry_id', array(date("Y-m-d"), $last_entry))->max('nutrisi'); 
		// $ph = DB::table('tb_status_tanaman')->max('air_tanah');
		// $cahaya = DB::table('tb_status_tanaman')->max('cahaya');
		// $humadity = DB::table('tb_status_tanaman')->max('kelembaban');
		// $level_water = DB::table('tb_status_tanaman')->max('tangki_air');
		// $temperature = DB::table('tb_status_tanaman')->max('suhu');


		// if ($cahaya <= 120) {
		// 	$cahaya = Notification::where('id_notif', '=', 1)->first();
		// }
		// else if($cahaya >= 120) {
		// 	$cahaya = Notification::where('id_notif', '=', 2)->first();
		// }

		// if($moisture <= 120) {
		// 	$moisture = Notification::where('id_notif', '=', 1)->first();
		// }
		// else if($moisture >= 120) {
		// 	$moisture = Notification::where('id_notif', '=', 2)->first();
		// }

		// if($ph <= 120) {
		// 	$ph = Notification::where('id_notif', '=', 1)->first();
		// }
		// else if($ph >= 120) {
		// 	$ph = Notification::where('id_notif', '=', 2)->first();
		// }

		// if($humadity <= 56) {
		// 	$humadity = Notification::where('id_notif', '=', 1)->first();
		// }
		// else if($humadity >= 56) {
		// 	$humadity = Notification::where('id_notif', '=', 2)->first();
		// }

		// if($level_water <= 120) {
		// 	$level_water = Notification::where('id_notif', '=', 1)->first();
		// }
		// else if($level_water >= 120) {
		// 	$level_water = Notification::where('id_notif', '=', 2)->first();
		// }

		// if($temperature <= 120) {
		// 	$temperature = Notification::where('id_notif', '=', 1)->first();
		// }
		// else if($temperature >= 120) {
		// 	$temperature = Notification::where('id_notif', '=', 2)->first();
		// }



		// $qry =StatusTanaman::where('id_tanaman', '=', 19)->select('created_at', 'id_device')->get();
        	

  //   	// $valuee = StatusTanaman::where('id_status_tanaman', '=', 105)->first();
  //   	// $tanggal = date("Y-m-d H:i:s", strtotime($valuee['created_at']));

  //   	$now_hours = date("Y-m-d H:i:s");
  //   	if ($now_hours <= date("Y-m-d 06:10:00")) {
  //   		$now_hours = 'terlalu pagi coy';
  //   	}
  //   	else if ($now_hours <= date("Y-m-d 11:00:00")) {
  //   		$now_hours = 'pagi';

  //   	}
  //   	else if ($now_hours <= date("Y-m-d 14:30:00")){
  //   		$now_hours = 'siang';
  //   	}
  //   	else if ($now_hours <= date("Y-m-d 17:30:00")) {
  //   		$now_hours = 'sore';
  //   	}
  //   	else if ($now_hours <= date("Y-m-d 24:00:00")) {
  //   		$now_hours = 'malem bgt sih';
  //   	}
    	
    	return response()->json([
			'msg'  	  => 'success',
			'data' 	  => $last_entry,
			'status'  => 200
		]); 
    }

    public function teye($id){
    	//keterangan
		//temperature = field1 = suhu 
		//humadity = field2 = kelembaban
		//light = field4 = cahaya
		//level_water = field5 = tangki_air
		//ph = field6 = field6 = air_tanah
		//rssi = field7
		//moisture = field3 = nutrisi

    	// $channel = StatusTanaman::where('id_device', '=', $id)->select('id_device')->with('device')->first();
    	$channel = StatusTanaman::where('id_channel', '=', $id)->select('id_device')->with('device')->first();
    	$now_hours = date("Y-m-d H:i:s");
    	// $now_hours = date("Y-m-d 07:00:00");

    	

	    	if ($now_hours <= date("Y-m-d 06:10:00")) {
	    		$now_hours = 'terlalu pagi coy';
	    		$cahaya = 'tanaman istirahat';
	    		$ph = 'tanaman istirahat';
	    		$humadity = 'tanaman istirahat';
	    		$temperature = 'tanaman istirahat';
	    		$moisture = 'tanaman istirahat';
	    		$level_water = 'tanaman istirahat';
	    	}
	    	// 06 ~ 11
	    	else if ($now_hours <= date("Y-m-d 11:00:00")) {
	    		$now_hours = 'pagi';
	    		$dari = date("Y-m-d 06:00:00");
	    		$sampai = date("Y-m-d 10:30:00");

	    		// cahaya
	        	$cahaya = DB::table('tb_status_tanaman')->where('id_device', '=', $id)->where('created_at', '>=', $dari)->where('created_at', '<=', $sampai)->max('cahaya'); 
	    		// dd($cahaya);

	    		if ($cahaya >= 30) {
	    			$cahaya = 'cahaya pagi berlebih men';
	    		}
	        	else if($cahaya < 30 && $cahaya >= 15) {
					$cahaya = 'cahaya pagi aman men';
				}
				else if ($cahaya < 15 && $cahaya >= 1) {
					$cahaya = 'cahaya pagi kurang men';
				}
				else {
					$cahaya = 'data kosong'; 
				}

				// ph
	        	$ph = DB::table('tb_status_tanaman')->where('id_device', '=', $id)->where('created_at', '>=', $dari)->where('created_at', '<=', $sampai)->max('air_tanah'); 
				
				if ($ph >= 30) {
	    			$ph = 'ph pagi berlebih men';
	    		}
	        	else if($ph < 30 && $ph >= 15) {
					$ph = 'ph pagi aman men';
				}
				else if($ph < 15 && $ph >= 1) {
					$ph = 'ph pagi kurang men';
				}
				else {
					$ph = 'data kosong';
				}

				// moisture
				$moisture = DB::table('tb_status_tanaman')->where('id_device', '=', $id)->where('created_at', '>=', $dari)->where('created_at', '<=', $sampai)->max('nutrisi'); 
				
				if ($moisture >= 30) {
	    			$moisture = 'moisture pagi berlebih men';
	    		}
	        	else if($moisture < 30 && $moisture >= 15) {
					$moisture = 'moisture pagi aman men';
				}
				else if($moisture < 15 && $moisture >= 1) {
					$moisture = 'moisture pagi kurang men';
				}
				else {
					$moisture = 'data kosong';
				}

				// humadity
				$humadity = DB::table('tb_status_tanaman')->where('id_device', '=', $id)->where('created_at', '>=', $dari)->where('created_at', '<=', $sampai)->max('kelembaban');
				
				if ($humadity >= 30) {
	    			$humadity = 'humadity pagi berlebih men';
	    		}
	        	else if($humadity < 30 && $humadity >= 15) {
					$humadity = 'humadity pagi aman men';
				}
				else if($humadity < 15 && $humadity >= 1) {
					$humadity = 'humadity pagi kurang men';
				}
				else {
					$humadity = 'data kosong';
				}

				// level_water
				$level_water = DB::table('tb_status_tanaman')->where('id_device', '=', $id)->where('created_at', '>=', $dari)->where('created_at', '<=', $sampai)->max('tangki_air');
				
				if ($level_water == 3) {
	    			$level_water = 'level_water pagi penuh men';
	    		}
	        	else if($level_water == 2) {
					$level_water = 'level_water pagi sedang men';
				}
				else if($level_water == 1) {
					$level_water = 'level_water pagi kurang men';
				}
				else {
					$level_water = 'data kosong';
				}	

				// temperature
				$temperature = DB::table('tb_status_tanaman')->where('id_device', '=', $id)->where('created_at', '>=', $dari)->where('created_at', '<=', $sampai)->max('suhu');
				

				if ($temperature >= 30) {
	    			$temperature = 'temperatur pagi berlebih men';
	    		}
	        	else if($temperature < 30 && $temperature >= 15) {
					$temperature = 'temperatur pagi aman men';
				}
				else if($temperature < 15 && $temperature >= 1) {
					$temperature = 'temperatur pagi kurang men';
				}
				else {
					$temperature = 'data kosong';
				}	
	    	}
	    	// 11 ~ 14
	    	else if ($now_hours <= date("Y-m-d 14:30:00")){
	    		$now_hours = 'siang';
	    		$dari = date("Y-m-d 11:00:00");
	    		$sampai = date("Y-m-d 14:30:00");

	    		// cahaya = field4 = light
	        	$cahaya = DB::table('tb_status_tanaman')->where('id_device', '=', $id)->where('created_at', '>=', $dari)->where('created_at', '<=', $sampai)->max('cahaya'); 
	    		// dd($cahaya);

	    		if ($cahaya >= 30) {
	    			// $cahaya = 'cahaya siang berlebih men';
	    			$cahaya = Notification::where('id_notif', '=', 2)->first();
	    		}
	        	else if($cahaya < 30 && $cahaya >= 15) {
					$cahaya = 'cahaya siang aman men';
				}
				else if ($cahaya < 15 && $cahaya >= 1) {
					// $cahaya = 'cahaya siang kurang men';
					$cahaya = Notification::where('id_notif', '=', 1)->first();
				}
				else {
					$cahaya = 'data cahaya kosong'; 
				}

				//ph = field6 = field6 = air_tanah
	        	$ph = DB::table('tb_status_tanaman')->where('id_device', '=', $id)->where('created_at', '>=', $dari)->where('created_at', '<=', $sampai)->max('air_tanah'); 
				
				if ($ph >= 30) {
	    			// $ph = 'ph siang berlebih men';
	    			$ph = Notification::where('id_notif', '=', 10)->first();
	    		}
	        	else if($ph < 30 && $ph >= 15) {
					$ph = 'ph siang aman men';
				}
				else if($ph < 15 && $ph >= 1) {
					// $ph = 'ph siang kurang men';
	    			$ph = Notification::where('id_notif', '=', 9)->first();
				}
				else {
					$ph = 'data ph kosong';
				}

				// moisture = field3 = nutrisi
				$moisture = DB::table('tb_status_tanaman')->where('id_device', '=', $id)->where('created_at', '>=', $dari)->where('created_at', '<=', $sampai)->max('nutrisi'); 
				
				if ($moisture >= 30) {
	    			$moisture = 'moisture siang berlebih men';
	    		}
	        	else if($moisture < 30 && $moisture >= 15) {
					$moisture = 'moisture siang aman men';
				}
				else if($moisture < 15 && $moisture >= 1) {
					$moisture = 'moisture siang kurang men';
				}
				else {
					$moisture = 'data moisture kosong';
				}


				//humadity = field2 = kelembaban
				$humadity = DB::table('tb_status_tanaman')->where('id_device', '=', $id)->where('created_at', '>=', $dari)->where('created_at', '<=', $sampai)->max('kelembaban');
				
				if ($humadity >= 30) {
	    			$humadity = 'humadity siang berlebih men';
	    		}
	        	else if($humadity < 30 && $humadity >= 15) {
					$humadity = 'humadity siang aman men';
				}
				else if($humadity < 15 && $humadity >= 1) {
					$humadity = 'humadity siang kurang men';
				}
				else {
					$humadity = 'data humadity kosong';
				}

				//level_water = field5 = tangki_air
				$level_water = DB::table('tb_status_tanaman')->where('id_device', '=', $id)->where('created_at', '>=', $dari)->where('created_at', '<=', $sampai)->max('tangki_air');
				
				if ($level_water == 3) {
	    			$level_water = 'level_water siang penuh men';
	    		}
	        	else if($level_water == 2) {
					$level_water = 'level_water siang sedang men';
				}
				else if($level_water == 1) {
					$level_water = 'level_water siang kurang men';
				}
				else {
					$level_water = 'data level_water kosong';
				}	

				
				//temperature = field1 = suhu 
				$temperature = DB::table('tb_status_tanaman')->where('id_device', '=', $id)->where('created_at', '>=', $dari)->where('created_at', '<=', $sampai)->max('suhu');
				

				if ($temperature >= 30) {
	    			$temperature = 'temperatur siang berlebih men';
	    		}
	        	else if($temperature < 30 && $temperature >= 15) {
					$temperature = 'temperatur siang aman men';
				}
				else if($temperature < 15 && $temperature >= 1) {
					$temperature = 'temperatur siang kurang men';
				}
				else {
					$temperature = 'data temperature kosong';
				}
	    	}
	    	// 14 ~ 17
	    	else if ($now_hours <= date("Y-m-d 17:30:00")) {
	    		$now_hours = 'sore';
	    		$dari = date("Y-m-d 14:30:00");
	    		$sampai = date("Y-m-d 17:00:00");
	    		
	    		// cahaya
	        	$cahaya = DB::table('tb_status_tanaman')->where('id_device', '=', $id)->where('created_at', '>=', $dari)->where('created_at', '<=', $sampai)->max('cahaya'); 
	    		// dd($cahaya);

	    		if ($cahaya >= 30) {
	    			$cahaya = 'cahaya sore berlebih men';
	    		}
	        	else if($cahaya < 30 && $cahaya >= 15) {
					$cahaya = 'cahaya sore aman men';
				}
				else if ($cahaya < 15 && $cahaya >= 1) {
					$cahaya = 'cahaya sore kurang men';
				}
				else {
					$cahaya = 'data kosong'; 
				}

				// ph
	        	$ph = DB::table('tb_status_tanaman')->where('id_device', '=', $id)->where('created_at', '>=', $dari)->where('created_at', '<=', $sampai)->max('air_tanah'); 
				
				if ($ph >= 30) {
	    			$ph = 'ph sore berlebih men';
	    		}
	        	else if($ph < 30 && $ph >= 15) {
					$ph = 'ph sore aman men';
				}
				else if($ph < 15 && $ph >= 1) {
					$ph = 'ph sore kurang men';
				}
				else {
					$ph = 'data kosong';
				}

				// moisture
				$moisture = DB::table('tb_status_tanaman')->where('id_device', '=', $id)->where('created_at', '>=', $dari)->where('created_at', '<=', $sampai)->max('nutrisi'); 
				
				if ($moisture >= 30) {
	    			$moisture = 'moisture sore berlebih men';
	    		}
	        	else if($moisture < 30 && $moisture >= 15) {
					$moisture = 'moisture sore aman men';
				}
				else if($moisture < 15 && $moisture >= 1) {
					$moisture = 'moisture sore kurang men';
				}
				else {
					$moisture = 'data kosong';
				}

				// humadity
				$humadity = DB::table('tb_status_tanaman')->where('id_device', '=', $id)->where('created_at', '>=', $dari)->where('created_at', '<=', $sampai)->max('kelembaban');
				
				if ($humadity >= 30) {
	    			$humadity = 'humadity sore berlebih men';
	    		}
	        	else if($humadity < 30 && $humadity >= 15) {
					$humadity = 'humadity sore aman men';
				}
				else if($humadity < 15 && $humadity >= 1) {
					$humadity = 'humadity sore kurang men';
				}
				else {
					$humadity = 'data kosong';
				}

				// level_water
				$level_water = DB::table('tb_status_tanaman')->where('id_device', '=', $id)->where('created_at', '>=', $dari)->where('created_at', '<=', $sampai)->max('tangki_air');
				
				if ($level_water == 3) {
	    			$level_water = 'level_water sore penuh men';
	    		}
	        	else if($level_water == 2) {
					$level_water = 'level_water sore sedang men';
				}
				else if($level_water == 1) {
					$level_water = 'level_water sore kurang men';
				}
				else {
					$level_water = 'data kosong';
				}	

				// temperature
				$temperature = DB::table('tb_status_tanaman')->where('id_device', '=', $id)->where('created_at', '>=', $dari)->where('created_at', '<=', $sampai)->max('suhu');
				

				if ($temperature >= 30) {
	    			$temperature = 'temperatur sore berlebih men';
	    		}
	        	else if($temperature < 30 && $temperature >= 15) {
					$temperature = 'temperatur sore aman men';
				}
				else if($temperature < 15 && $temperature >= 1) {
					$temperature = 'temperatur sore kurang men';
				}
				else {
					$temperature = 'data kosong';
				}
	    	}
	    	// 17 ~ 24
	    	else if ($now_hours <= date("Y-m-d 24:00:00")) {
	    		$now_hours = 'malem bgt sih';
	    		$cahaya = 'tanaman istirahat';
	    		$ph = 'tanaman istirahat';
	    		$humadity = 'tanaman istirahat';
	    		$temperature = 'tanaman istirahat';
	    		$moisture = 'tanaman istirahat';
	    		$level_water = 'tanaman istirahat';
	    	}



    	return response()->json([
			'msg'  	  		=> 'success',
			'channel'		=> $channel,
			'waktu' 	  	=> $now_hours,
			'cahaya'  		=> $cahaya,
			'ph'  			=> $ph,
			'temperature' 	=> $temperature,
			'moisture'		=> $moisture,
			'humadity'		=> $humadity,
			'level_water'	=> $level_water,
			'status'  		=> 200
		]);
    }
    public function getPemupukanWithId($id){
    	$qry =Tanaman::where('id_tanaman', '=', $id)->first();
    	if (empty($qry)) {
    		return 'data kosong';
    	}
    	else {
	    	// $qry =Tanaman::where('id_tanaman', '=', $id)->first();
	    	$tanam = date("Y-m-d", strtotime($qry['tgl_tanam']));
	    	$datetime1 = new Carbon($tanam);
		    $datetime2 = now();
		    $interval = date_diff($datetime1, $datetime2);
		    $interval = $datetime1->diff($datetime2);
		    $now_usia = $interval->format('%a');
		    $qry['usia'] = $now_usia;

		    if ($now_usia == 15) {
	    		$pupuk = 'waktunya pemupukan';
	        }
	        else if ($now_usia > 15) {
	        	$pupuk = 'Waktu ideal pemupukan sudah berlalu';
	        }
	        else {
	        	$pupuk = 'Belum waktunya pemupukan';
	        }

        	$qry['pupuk'] = $pupuk;
    	}

    	return response()->json([
			'msg'  	  		=> 'success',
			'data'			=> $qry,
			'status'  		=> 200
		]);


    }

}
